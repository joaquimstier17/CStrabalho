<?php
// dashboard.php - Área restrita (Protegida)
session_start();

// Verifica se a sessão está ativa
if (!isset($_SESSION['usuario_id'])) {
    header('Location: index.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Painel Principal - Área Restrita</title>
    <style>
        body { font-family: sans-serif; background: #f4f6f9; margin: 0; padding: 40px; }
        .container { background: #fff; padding: 30px; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); max-width: 600px; margin: 0 auto; }
        h1 { color: #333; margin-top: 0; }
        p { color: #555; line-height: 1.6; }
        .badge { background: #e9ecef; padding: 5px 10px; border-radius: 4px; font-family: monospace; }
        .btn-logout { display: inline-block; padding: 10px 20px; background: #dc3545; color: #fff; text-decoration: none; border-radius: 4px; margin-top: 20px; }
        .btn-logout:hover { background: #bd2130; }
    </style>
</head>
<body>
<div class="container">
    <h1>Bem-vindo(a), <?= htmlspecialchars($_SESSION['usuario_nome']) ?>!</h1>
    <p>Você está acessando uma área restrita e autenticada com sucesso.</p>
    <ul>
        <li><strong>ID do Usuário:</strong> <span class="badge"><?= htmlspecialchars($_SESSION['usuario_id']) ?></span></li>
        <li><strong>E-mail:</strong> <span class="badge"><?= htmlspecialchars($_SESSION['usuario_email']) ?></span></li>
    </ul>
    <a href="logout.php" class="btn-logout">Sair / Logout</a>
</div>
</body>
</html>
