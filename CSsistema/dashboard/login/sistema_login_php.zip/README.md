# Sistema de Login Simples em PHP com Hashing Seguro

Este projeto demonstra como implementar um sistema de autenticação simples, seguro e funcional utilizando PHP e MySQL.

## Recursos Implementados
- **PDO (PHP Data Objects)** com Prepared Statements para prevenção contra SQL Injection.
- **`password_hash()`** com `PASSWORD_DEFAULT` (BCrypt / Argon2) para armazenamento seguro de senhas.
- **`password_verify()`** para checagem segura no login.
- **`session_regenerate_id(true)`** para prevenção contra ataques de Session Fixation.
- Proteção de rotas com verificação de sessão (`dashboard.php`).
- Escape HTML com `htmlspecialchars()` contra XSS.

## Como Executar
1. Importe o arquivo `schema.sql` no seu servidor MySQL (ex: phpMyAdmin, DBeaver, MySQL Workbench).
2. Configure as credenciais de banco de dados em `conexao.php`.
3. Inicie seu ambiente local (XAMPP, WAMP, Laragon, Docker ou o servidor imbutido do PHP: `php -S localhost:8000`).
4. Acesse `http://localhost:8000/cadastro.php` para criar uma conta e testar o login.
