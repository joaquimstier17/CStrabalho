<?php
// cadastro.php - Tela e processamento de cadastro
require_once 'conexao.php';

$mensagem = '';
$tipoMensagem = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $senha = $_POST['senha'] ?? '';

    if (empty($nome) || empty($email) || empty($senha)) {
        $mensagem = 'Preencha todos os campos.';
        $tipoMensagem = 'erro';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $mensagem = 'E-mail inválido.';
        $tipoMensagem = 'erro';
    } else {
        // Hash seguro da senha utilizando BCrypt / Argon2 (PADRÃO do PHP)
        $senhaHash = password_hash($senha, PASSWORD_DEFAULT);

        try {
            $stmt = $pdo->prepare("INSERT INTO usuarios (nome, email, senha) VALUES (:nome, :email, :senha)");
            $stmt->execute([
                ':nome' => $nome,
                ':email' => $email,
                ':senha' => $senhaHash
            ]);
            $mensagem = 'Cadastro realizado com sucesso! Você já pode entrar.';
            $tipoMensagem = 'sucesso';
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) { // Erro de duplicação de e-mail
                $mensagem = 'Este e-mail já está cadastrado.';
            } else {
                $mensagem = 'Erro ao cadastrar usuário.';
            }
            $tipoMensagem = 'erro';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Cadastro - Sistema de Login</title>
    <style>
        body { font-family: sans-serif; background: #f4f6f9; display: flex; justify-content: center; align-items: center; min-height: 100vh; margin: 0; }
        .card { background: #fff; padding: 30px; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); width: 100%; max-width: 400px; }
        h2 { margin-top: 0; color: #333; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; color: #666; font-size: 14px; }
        input { width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; }
        button { width: 100%; padding: 10px; background: #28a745; border: none; color: #fff; font-size: 16px; border-radius: 4px; cursor: pointer; }
        button:hover { background: #218838; }
        .msg { padding: 10px; border-radius: 4px; margin-bottom: 15px; font-size: 14px; }
        .msg.erro { background: #f8d7da; color: #721c24; }
        .msg.sucesso { background: #d4edda; color: #155724; }
        a { color: #007bff; text-decoration: none; }
    </style>
</head>
<body>
<div class="card">
    <h2>Criar Conta</h2>
    <?php if ($mensagem): ?>
        <div class="msg <?= $tipoMensagem ?>"><?= htmlspecialchars($mensagem) ?></div>
    <?php endif; ?>
    <form method="POST" action="cadastro.php">
        <div class="form-group">
            <label>Nome Completo</label>
            <input type="text" name="nome" required>
        </div>
        <div class="form-group">
            <label>E-mail</label>
            <input type="email" name="email" required>
        </div>
        <div class="form-group">
            <label>Senha</label>
            <input type="password" name="senha" required minlength="6">
        </div>
        <button type="submit">Cadastrar</button>
    </form>
    <p style="margin-top: 15px; text-align: center; font-size: 14px;">
        Já tem uma conta? <a href="index.php">Faça Login</a>
    </p>
</div>
</body>
</html>
