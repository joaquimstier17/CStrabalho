<?php
// index.php - Tela e processamento de Login
session_start();
require_once 'conexao.php';

// Se já estiver logado, redireciona para a área restrita
if (isset($_SESSION['usuario_id'])) {
    header('Location: dashboard.php');
    exit;
}

$erro = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $senha = $_POST['senha'] ?? '';

    if (empty($email) || empty($senha)) {
        $erro = 'Informe o e-mail e a senha.';
    } else {
        // Busca o usuário pelo e-mail
        $stmt = $pdo->prepare("SELECT id, nome, email, senha FROM usuarios WHERE email = :email");
        $stmt->execute([':email' => $email]);
        $usuario = $stmt->fetch();

        // Verifica a senha usando password_verify()
        if ($usuario && password_verify($senha, $usuario['senha'])) {
            // Prevenção contra Session Fixation
            session_regenerate_id(true);

            // Armazena dados essenciais na sessão
            $_SESSION['usuario_id'] = $usuario['id'];
            $_SESSION['usuario_nome'] = $usuario['nome'];
            $_SESSION['usuario_email'] = $usuario['email'];

            header('Location: dashboard.php');
            exit;
        } else {
            // Mensagem genérica por segurança
            $erro = 'E-mail ou senha incorretos.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Login - Sistema de Login</title>
    <style>
        body { font-family: sans-serif; background: #f4f6f9; display: flex; justify-content: center; align-items: center; min-height: 100vh; margin: 0; }
        .card { background: #fff; padding: 30px; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); width: 100%; max-width: 400px; }
        h2 { margin-top: 0; color: #333; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; color: #666; font-size: 14px; }
        input { width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; }
        button { width: 100%; padding: 10px; background: #007bff; border: none; color: #fff; font-size: 16px; border-radius: 4px; cursor: pointer; }
        button:hover { background: #0056b3; }
        .msg.erro { background: #f8d7da; color: #721c24; padding: 10px; border-radius: 4px; margin-bottom: 15px; font-size: 14px; }
        a { color: #007bff; text-decoration: none; }
    </style>
</head>
<body>
<div class="card">
    <h2>Entrar no Sistema</h2>
    <?php if ($erro): ?>
        <div class="msg erro"><?= htmlspecialchars($erro) ?></div>
    <?php endif; ?>
    <form method="POST" action="index.php">
        <div class="form-group">
            <label>E-mail</label>
            <input type="email" name="email" required>
        </div>
        <div class="form-group">
            <label>Senha</label>
            <input type="password" name="senha" required>
        </div>
        <button type="submit">Entrar</button>
    </form>
    <p style="margin-top: 15px; text-align: center; font-size: 14px;">
        Não tem uma conta? <a href="cadastro.php">Cadastre-se</a>
    </p>
</div>
</body>
</html>
