-- ========================================================
-- BANCO DE DADOS CS-SCOUT
-- ========================================================

CREATE DATABASE IF NOT EXISTS cs_scout CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE cs_scout;

-- --------------------------------------------------------
-- TABELA: usuarios
-- --------------------------------------------------------
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    usuario VARCHAR(50) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL,
    nivel ENUM('admin', 'usuario') NOT NULL DEFAULT 'usuario',
    criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_usuario (usuario),
    INDEX idx_nivel (nivel)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- TABELA: jogadores
-- --------------------------------------------------------
CREATE TABLE jogadores (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    nickname VARCHAR(100) NOT NULL,
    equipe VARCHAR(100) DEFAULT NULL,
    tempo VARCHAR(20) DEFAULT '0h',
    vitorias INT NOT NULL DEFAULT 0,
    derrotas INT NOT NULL DEFAULT 0,
    kills INT NOT NULL DEFAULT 0,
    rounds INT NOT NULL DEFAULT 0,
    rating DECIMAL(4,2) NOT NULL DEFAULT 0.00,
    kast DECIMAL(5,2) NOT NULL DEFAULT 0.00,
    impact_rating DECIMAL(4,2) NOT NULL DEFAULT 0.00,
    adr DECIMAL(5,2) NOT NULL DEFAULT 0.00,
    clutches INT NOT NULL DEFAULT 0,
    status ENUM('ativo', 'inativo') NOT NULL DEFAULT 'ativo',
    criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
    atualizado_em DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_nickname (nickname),
    INDEX idx_status (status),
    INDEX idx_equipe (equipe)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- USUARIO ADMINISTRADOR INICIAL
-- Senha: admin123
-- --------------------------------------------------------
INSERT INTO usuarios (nome, usuario, senha, nivel) VALUES
('Administrador', 'admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');

-- --------------------------------------------------------
-- JOGADORES DE EXEMPLO
-- --------------------------------------------------------
INSERT INTO jogadores (nome, nickname, equipe, tempo, vitorias, derrotas, kills, rounds, rating, kast, impact_rating, adr, clutches, status) VALUES
('Gabriel Toledo', 'FalleN', 'FURIA', '2.450h', 320, 180, 15420, 8500, 1.18, 72.50, 1.22, 78.40, 45, 'ativo'),
('Marcelo David', 'coldzera', 'Legacy', '3.120h', 410, 220, 22100, 12000, 1.25, 75.20, 1.35, 85.60, 62, 'ativo'),
('Fernando Alvarenga', 'fer', 'Imperial', '2.890h', 380, 240, 19800, 10500, 1.12, 68.40, 1.15, 72.30, 38, 'ativo'),
('Epitacio de Melo', 'TACO', '00NATION', '2.670h', 350, 210, 17600, 9800, 1.08, 70.10, 1.08, 69.50, 29, 'ativo'),
('Ricardo Mulando', 'boltz', 'FURIA', '2.100h', 290, 160, 14200, 7800, 1.15, 73.80, 1.20, 76.20, 41, 'ativo'),
('Vinicius Figueiredo', 'VINI', 'Legacy', '1.890h', 260, 190, 12800, 7200, 1.05, 66.30, 1.02, 65.80, 22, 'ativo'),
('Yuri Santos', 'yuurih', 'FURIA', '1.560h', 220, 140, 11200, 6500, 1.20, 74.60, 1.28, 81.40, 35, 'ativo'),
('Kaike Cerato', 'KSCERATO', 'FURIA', '1.780h', 250, 150, 13500, 7100, 1.22, 76.10, 1.30, 83.20, 48, 'ativo'),
('Andrei Piovezan', 'arT', 'FURIA', '1.920h', 270, 170, 14800, 8000, 1.10, 69.80, 1.12, 71.50, 31, 'ativo'),
('Felipe Medeiros', 'skullz', 'Imperial', '1.340h', 180, 120, 9500, 5400, 1.14, 71.20, 1.18, 74.60, 27, 'ativo'),
('Lucas Soares', 'lux', 'paiN', '1.120h', 150, 100, 8200, 4800, 1.16, 72.90, 1.24, 77.80, 33, 'ativo'),
('Rodrigo Bittencourt', 'biguzera', 'paiN', '1.450h', 200, 130, 10800, 5900, 1.13, 70.50, 1.16, 73.40, 26, 'ativo');
