<?php
session_start();
require_once 'config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

$isAdmin = $_SESSION['user_nivel'] === 'admin';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CS-Scout | Perfil</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <button class="mobile-toggle">☰</button>
    <div class="sidebar-overlay"></div>

    <aside class="sidebar">
        <div class="sidebar-header">
            <a href="estatisticas.php" class="sidebar-logo">
                <div class="sidebar-logo-icon">CS</div>
                <div class="sidebar-logo-text">CS-<span>Scout</span></div>
            </a>
        </div>

        <nav class="sidebar-nav">
            <a href="estatisticas.php" class="nav-item">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
                Estatísticas
            </a>

            <?php if ($isAdmin): ?>
            <a href="admin/jogadores.php" class="nav-item">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                Jogadores
            </a>
            <a href="admin/dashboard.php" class="nav-item">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
                Dashboard
            </a>
            <?php endif; ?>

            <a href="perfil.php" class="nav-item active">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                Perfil
            </a>

            <button class="nav-item logout">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
                Sair
            </button>
        </nav>

        <div class="sidebar-footer">CS-Scout v1.0</div>
    </aside>

    <main class="main-content">
        <div class="page-header">
            <div>
                <h1 class="page-title">Meu <span>Perfil</span></h1>
                <p class="page-subtitle">Informações da sua conta</p>
            </div>
            <div class="user-info">
                <div class="user-details">
                    <div class="user-name"><?php echo htmlspecialchars($_SESSION['user_nome']); ?></div>
                    <div class="user-role"><?php echo $_SESSION['user_nivel']; ?></div>
                </div>
                <div class="user-avatar"><?php echo strtoupper(substr($_SESSION['user_nome'], 0, 1)); ?></div>
            </div>
        </div>

        <div class="card" style="max-width:500px">
            <div style="display:flex;align-items:center;gap:20px;margin-bottom:24px">
                <div class="user-avatar" style="width:80px;height:80px;font-size:32px">
                    <?php echo strtoupper(substr($_SESSION['user_nome'], 0, 1)); ?>
                </div>
                <div>
                    <h2 style="font-size:22px;font-weight:700"><?php echo htmlspecialchars($_SESSION['user_nome']); ?></h2>
                    <p style="color:var(--text-muted);font-size:14px">@<?php echo htmlspecialchars($_SESSION['user_usuario']); ?></p>
                    <span class="badge <?php echo $isAdmin ? 'badge-ativo' : 'badge-inativo'; ?>" style="margin-top:8px;display:inline-block">
                        <?php echo strtoupper($_SESSION['user_nivel']); ?>
                    </span>
                </div>
            </div>

            <div style="border-top:1px solid var(--border-color);padding-top:20px">
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px">
                    <div>
                        <p style="font-size:12px;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.5px">Usuário</p>
                        <p style="font-weight:600;margin-top:4px"><?php echo htmlspecialchars($_SESSION['user_usuario']); ?></p>
                    </div>
                    <div>
                        <p style="font-size:12px;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.5px">Nível de Acesso</p>
                        <p style="font-weight:600;margin-top:4px"><?php echo ucfirst($_SESSION['user_nivel']); ?></p>
                    </div>
                    <div>
                        <p style="font-size:12px;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.5px">ID</p>
                        <p style="font-weight:600;margin-top:4px">#<?php echo $_SESSION['user_id']; ?></p>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <script src="assets/js/app.js"></script>
</body>
</html>
