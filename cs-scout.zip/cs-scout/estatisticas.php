<?php
session_start();
require_once 'config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

$isAdmin = $_SESSION['user_nivel'] === 'admin';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CS-Scout | Estatísticas</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body data-admin="<?php echo $isAdmin ? '1' : '0'; ?>">
    <button class="mobile-toggle">☰</button>
    <div class="sidebar-overlay"></div>

    <aside class="sidebar">
        <div class="sidebar-header">
            <a href="estatisticas.php" class="sidebar-logo">
                <div class="sidebar-logo-icon">CS</div>
                <div class="sidebar-logo-text">CS-<span>Scout</span></div>
            </a>
        </div>

        <nav class="sidebar-nav">
            <a href="estatisticas.php" class="nav-item active">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
                Estatísticas
            </a>

            <?php if ($isAdmin): ?>
            <a href="admin/jogadores.php" class="nav-item">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                Jogadores
            </a>
            <a href="admin/dashboard.php" class="nav-item">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
                Dashboard
            </a>
            <?php endif; ?>

            <a href="perfil.php" class="nav-item">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                Perfil
            </a>

            <button class="nav-item logout">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
                Sair
            </button>
        </nav>

        <div class="sidebar-footer">
            CS-Scout v1.0
        </div>
    </aside>

    <main class="main-content">
        <div class="page-header">
            <div>
                <h1 class="page-title">Estatísticas dos <span>Jogadores</span></h1>
                <p class="page-subtitle">Acompanhe o desempenho dos jogadores de Counter-Strike</p>
            </div>
            <div class="user-info">
                <div class="user-details">
                    <div class="user-name"><?php echo htmlspecialchars($_SESSION['user_nome']); ?></div>
                    <div class="user-role"><?php echo $_SESSION['user_nivel']; ?></div>
                </div>
                <div class="user-avatar"><?php echo strtoupper(substr($_SESSION['user_nome'], 0, 1)); ?></div>
            </div>
        </div>

        <div class="search-bar">
            <input type="text" id="search-jogadores" class="search-input" placeholder="Pesquisar por nome, nickname ou equipe...">

            <?php if ($isAdmin): ?>
            <button id="btn-cadastrar" class="btn btn-primary">
                <span>+</span> Cadastrar Jogador
            </button>
            <?php endif; ?>
        </div>

        <div class="card">
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th class="sortable" data-sort="nome">Nome <span class="sort-icon">⇅</span></th>
                            <th class="sortable" data-sort="equipe">Equipe <span class="sort-icon">⇅</span></th>
                            <th class="sortable" data-sort="tempo">Tempo <span class="sort-icon">⇅</span></th>
                            <th class="sortable" data-sort="vitorias">V <span class="sort-icon">⇅</span></th>
                            <th class="sortable" data-sort="derrotas">D <span class="sort-icon">⇅</span></th>
                            <th class="sortable" data-sort="kills">K <span class="sort-icon">⇅</span></th>
                            <th class="sortable" data-sort="rounds">R <span class="sort-icon">⇅</span></th>
                            <th class="sortable" data-sort="rating">SR <span class="sort-icon">⇅</span></th>
                            <th class="sortable" data-sort="kast">KAST% <span class="sort-icon">⇅</span></th>
                            <th class="sortable" data-sort="impact_rating">IR <span class="sort-icon">⇅</span></th>
                            <th class="sortable" data-sort="adr">ADR <span class="sort-icon">⇅</span></th>
                            <th class="sortable" data-sort="clutches">C <span class="sort-icon">⇅</span></th>
                            <?php if ($isAdmin): ?><th>Ações</th><?php endif; ?>
                        </tr>
                    </thead>
                    <tbody id="tabela-jogadores">
                        <tr><td colspan="13" style="text-align:center;padding:40px;color:var(--text-muted)">Carregando...</td></tr>
                    </tbody>
                </table>
            </div>

            <div id="paginacao" class="pagination"></div>
        </div>
    </main>

    <?php if ($isAdmin): ?>
    <!-- Modal Cadastrar/Editar -->
    <div id="modal-cadastrar" class="modal-overlay">
        <div class="modal">
            <div class="modal-header">
                <h3 id="modal-cadastrar-title" class="modal-title">Cadastrar Jogador</h3>
                <button class="modal-close">&times;</button>
            </div>
            <form id="form-cadastrar">
                <input type="hidden" id="jogador-id" name="id">
                <div class="modal-body">
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Nome</label>
                            <input type="text" id="cad-nome" name="nome" class="form-input" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Nickname</label>
                            <input type="text" id="cad-nickname" name="nickname" class="form-input" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Equipe</label>
                            <input type="text" id="cad-equipe" name="equipe" class="form-input">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Tempo de Jogo</label>
                            <input type="text" id="cad-tempo" name="tempo" class="form-input" placeholder="ex: 1.250h">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Vitórias</label>
                            <input type="number" id="cad-vitorias" name="vitorias" class="form-input" value="0" min="0">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Derrotas</label>
                            <input type="number" id="cad-derrotas" name="derrotas" class="form-input" value="0" min="0">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Kills</label>
                            <input type="number" id="cad-kills" name="kills" class="form-input" value="0" min="0">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Rounds</label>
                            <input type="number" id="cad-rounds" name="rounds" class="form-input" value="0" min="0">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Rating</label>
                            <input type="number" step="0.01" id="cad-rating" name="rating" class="form-input" value="1.00" min="0">
                        </div>
                        <div class="form-group">
                            <label class="form-label">KAST%</label>
                            <input type="number" step="0.01" id="cad-kast" name="kast" class="form-input" value="0" min="0" max="100">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Impact Rating</label>
                            <input type="number" step="0.01" id="cad-impact" name="impact_rating" class="form-input" value="1.00" min="0">
                        </div>
                        <div class="form-group">
                            <label class="form-label">ADR</label>
                            <input type="number" step="0.01" id="cad-adr" name="adr" class="form-input" value="0" min="0">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Clutches</label>
                        <input type="number" id="cad-clutches" name="clutches" class="form-input" value="0" min="0">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary modal-close-btn">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Salvar</button>
                </div>
            </form>
        </div>
    </div>
    <?php endif; ?>

    <script src="assets/js/app.js"></script>
    <script src="assets/js/jogadores.js"></script>
</body>
</html>
