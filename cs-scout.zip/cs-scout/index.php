<?php
session_start();
if (isset($_SESSION['user_id'])) {
    header('Location: ' . ($_SESSION['user_nivel'] === 'admin' ? 'admin/dashboard.php' : 'estatisticas.php'));
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CS-Scout | Login</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/login.css">
</head>
<body>
    <div class="login-page">
        <div class="login-bg"></div>

        <div class="login-card">
            <div class="login-logo">
                <div class="login-logo-icon">CS</div>
                <h1>CS-<span>Scout</span></h1>
                <p>Estatísticas de Jogadores Counter-Strike</p>
            </div>

            <div id="login-error" class="login-error"></div>

            <form id="login-form" class="login-form">
                <div class="form-group">
                    <label class="form-label" for="usuario">👤 Usuário</label>
                    <input type="text" id="usuario" name="usuario" class="form-input" placeholder="Digite seu usuário" autocomplete="username" required>
                </div>

                <div class="form-group">
                    <label class="form-label" for="senha">🔒 Senha</label>
                    <input type="password" id="senha" name="senha" class="form-input" placeholder="Digite sua senha" autocomplete="current-password" required>
                </div>

                <button type="submit" id="login-btn" class="login-btn">Entrar</button>
            </form>

            <div class="login-footer">
                <p>Usuário de teste: <strong>admin</strong> / Senha: <strong>admin123</strong></p>
                <p style="margin-top:8px">CS-Scout <span class="version">v1.0</span></p>
            </div>
        </div>
    </div>

    <script src="assets/js/app.js"></script>
    <script src="assets/js/login.js"></script>
</body>
</html>
