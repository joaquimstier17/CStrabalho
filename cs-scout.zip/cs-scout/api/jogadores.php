<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user_id'])) {
    jsonResponse(['success' => false, 'message' => 'Acesso negado. Faça login.']);
}

$acao = isset($_GET['acao']) ? $_GET['acao'] : 'listar';

switch ($acao) {
    case 'listar':
        $status = isset($_GET['status']) ? $_GET['status'] : 'ativo';
        $busca = isset($_GET['busca']) ? '%' . $_GET['busca'] . '%' : '%%';
        $ordenar = isset($_GET['ordenar']) ? $_GET['ordenar'] : 'rating';
        $ordem = isset($_GET['ordem']) && $_GET['ordem'] === 'asc' ? 'ASC' : 'DESC';
        $pagina = isset($_GET['pagina']) ? max(1, intval($_GET['pagina'])) : 1;
        $limite = isset($_GET['limite']) ? max(1, min(100, intval($_GET['limite']))) : 10;
        $offset = ($pagina - 1) * $limite;

        $colunasPermitidas = ['nome', 'nickname', 'equipe', 'tempo', 'vitorias', 'derrotas', 'kills', 'rounds', 'rating', 'kast', 'impact_rating', 'adr', 'clutches'];
        if (!in_array($ordenar, $colunasPermitidas)) {
            $ordenar = 'rating';
        }

        $where = "WHERE status = :status AND (nome LIKE :busca OR nickname LIKE :busca OR equipe LIKE :busca)";

        $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM jogadores {$where}");
        $stmt->execute([':status' => $status, ':busca' => $busca]);
        $total = $stmt->fetch()['total'];

        $stmt = $pdo->prepare("SELECT * FROM jogadores {$where} ORDER BY {$ordenar} {$ordem} LIMIT :limite OFFSET :offset");
        $stmt->bindValue(':status', $status);
        $stmt->bindValue(':busca', $busca);
        $stmt->bindValue(':limite', $limite, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        $jogadores = $stmt->fetchAll();

        jsonResponse([
            'success' => true,
            'jogadores' => $jogadores,
            'total' => $total,
            'pagina' => $pagina,
            'total_paginas' => ceil($total / $limite)
        ]);
        break;

    case 'obter':
        $id = isset($_GET['id']) ? intval($_GET['id']) : 0;
        if ($id <= 0) {
            jsonResponse(['success' => false, 'message' => 'ID inválido.']);
        }
        $stmt = $pdo->prepare("SELECT * FROM jogadores WHERE id = :id LIMIT 1");
        $stmt->execute([':id' => $id]);
        $jogador = $stmt->fetch();
        if (!$jogador) {
            jsonResponse(['success' => false, 'message' => 'Jogador não encontrado.']);
        }
        jsonResponse(['success' => true, 'jogador' => $jogador]);
        break;

    default:
        jsonResponse(['success' => false, 'message' => 'Ação inválida.']);
}
