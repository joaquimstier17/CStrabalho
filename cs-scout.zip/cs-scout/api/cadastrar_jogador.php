<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user_id']) || $_SESSION['user_nivel'] !== 'admin') {
    jsonResponse(['success' => false, 'message' => 'Acesso negado.']);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['success' => false, 'message' => 'Método não permitido.']);
}

$campos = ['nome', 'nickname', 'equipe', 'tempo', 'vitorias', 'derrotas', 'kills', 'rounds', 'rating', 'kast', 'impact_rating', 'adr', 'clutches'];
$dados = [];
foreach ($campos as $campo) {
    $dados[$campo] = isset($_POST[$campo]) ? trim($_POST[$campo]) : '';
}

if (empty($dados['nome']) || empty($dados['nickname'])) {
    jsonResponse(['success' => false, 'message' => 'Nome e Nickname são obrigatórios.']);
}

$stmt = $pdo->prepare("INSERT INTO jogadores 
    (nome, nickname, equipe, tempo, vitorias, derrotas, kills, rounds, rating, kast, impact_rating, adr, clutches, status) 
    VALUES 
    (:nome, :nickname, :equipe, :tempo, :vitorias, :derrotas, :kills, :rounds, :rating, :kast, :impact_rating, :adr, :clutches, 'ativo')");

try {
    $stmt->execute([
        ':nome' => $dados['nome'],
        ':nickname' => $dados['nickname'],
        ':equipe' => $dados['equipe'],
        ':tempo' => $dados['tempo'],
        ':vitorias' => intval($dados['vitorias']),
        ':derrotas' => intval($dados['derrotas']),
        ':kills' => intval($dados['kills']),
        ':rounds' => intval($dados['rounds']),
        ':rating' => floatval($dados['rating']),
        ':kast' => floatval($dados['kast']),
        ':impact_rating' => floatval($dados['impact_rating']),
        ':adr' => floatval($dados['adr']),
        ':clutches' => intval($dados['clutches'])
    ]);
    jsonResponse(['success' => true, 'message' => 'Jogador cadastrado com sucesso!', 'id' => $pdo->lastInsertId()]);
} catch (PDOException $e) {
    jsonResponse(['success' => false, 'message' => 'Erro ao cadastrar jogador: ' . $e->getMessage()]);
}
