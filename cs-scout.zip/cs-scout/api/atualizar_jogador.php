<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user_id']) || $_SESSION['user_nivel'] !== 'admin') {
    jsonResponse(['success' => false, 'message' => 'Acesso negado.']);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['success' => false, 'message' => 'Método não permitido.']);
}

$id = isset($_POST['id']) ? intval($_POST['id']) : 0;
if ($id <= 0) {
    jsonResponse(['success' => false, 'message' => 'ID inválido.']);
}

$campos = ['nome', 'nickname', 'equipe', 'tempo', 'vitorias', 'derrotas', 'kills', 'rounds', 'rating', 'kast', 'impact_rating', 'adr', 'clutches'];
$dados = [];
foreach ($campos as $campo) {
    $dados[$campo] = isset($_POST[$campo]) ? trim($_POST[$campo]) : '';
}

if (empty($dados['nome']) || empty($dados['nickname'])) {
    jsonResponse(['success' => false, 'message' => 'Nome e Nickname são obrigatórios.']);
}

$stmt = $pdo->prepare("UPDATE jogadores SET 
    nome = :nome, nickname = :nickname, equipe = :equipe, tempo = :tempo,
    vitorias = :vitorias, derrotas = :derrotas, kills = :kills, rounds = :rounds,
    rating = :rating, kast = :kast, impact_rating = :impact_rating, adr = :adr, clutches = :clutches
    WHERE id = :id");

try {
    $stmt->execute([
        ':id' => $id,
        ':nome' => $dados['nome'],
        ':nickname' => $dados['nickname'],
        ':equipe' => $dados['equipe'],
        ':tempo' => $dados['tempo'],
        ':vitorias' => intval($dados['vitorias']),
        ':derrotas' => intval($dados['derrotas']),
        ':kills' => intval($dados['kills']),
        ':rounds' => intval($dados['rounds']),
        ':rating' => floatval($dados['rating']),
        ':kast' => floatval($dados['kast']),
        ':impact_rating' => floatval($dados['impact_rating']),
        ':adr' => floatval($dados['adr']),
        ':clutches' => intval($dados['clutches'])
    ]);
    jsonResponse(['success' => true, 'message' => 'Jogador atualizado com sucesso!']);
} catch (PDOException $e) {
    jsonResponse(['success' => false, 'message' => 'Erro ao atualizar jogador: ' . $e->getMessage()]);
}
