<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['success' => false, 'message' => 'Método não permitido.']);
}

$usuario = isset($_POST['usuario']) ? trim($_POST['usuario']) : '';
$senha = isset($_POST['senha']) ? $_POST['senha'] : '';

if (empty($usuario) || empty($senha)) {
    jsonResponse(['success' => false, 'message' => 'Preencha todos os campos.']);
}

$stmt = $pdo->prepare("SELECT id, nome, usuario, senha, nivel FROM usuarios WHERE usuario = :usuario LIMIT 1");
$stmt->execute([':usuario' => $usuario]);
$user = $stmt->fetch();

if (!$user || !password_verify($senha, $user['senha'])) {
    jsonResponse(['success' => false, 'message' => 'Usuário ou senha incorretos.']);
}

$_SESSION['user_id'] = $user['id'];
$_SESSION['user_nome'] = $user['nome'];
$_SESSION['user_usuario'] = $user['usuario'];
$_SESSION['user_nivel'] = $user['nivel'];

jsonResponse([
    'success' => true,
    'message' => 'Login realizado com sucesso!',
    'nivel' => $user['nivel'],
    'redirect' => $user['nivel'] === 'admin' ? 'admin/dashboard.php' : 'estatisticas.php'
]);
