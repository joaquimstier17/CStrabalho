<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user_id'])) {
    jsonResponse(['success' => false, 'message' => 'Acesso negado.']);
}

// Estatísticas gerais
$stmt = $pdo->query("SELECT COUNT(*) as total FROM jogadores");
$totalJogadores = $stmt->fetch()['total'];

$stmt = $pdo->query("SELECT COUNT(*) as ativos FROM jogadores WHERE status = 'ativo'");
$jogadoresAtivos = $stmt->fetch()['ativos'];

$stmt = $pdo->query("SELECT COUNT(*) as inativos FROM jogadores WHERE status = 'inativo'");
$jogadoresInativos = $stmt->fetch()['inativos'];

$stmt = $pdo->query("SELECT SUM(vitorias + derrotas) as total_partidas FROM jogadores");
$totalPartidas = $stmt->fetch()['total_partidas'] ?? 0;

$stmt = $pdo->query("SELECT AVG(kills / NULLIF(derrotas, 0)) as media_kd FROM jogadores WHERE status = 'ativo' AND derrotas > 0");
$mediaKD = round($stmt->fetch()['media_kd'] ?? 0, 2);

$stmt = $pdo->query("SELECT AVG(adr) as media_adr FROM jogadores WHERE status = 'ativo'");
$mediaADR = round($stmt->fetch()['media_adr'] ?? 0, 2);

// Top 3 jogadores
$stmt = $pdo->query("SELECT nome, nickname, equipe, rating, adr, kast FROM jogadores WHERE status = 'ativo' ORDER BY rating DESC LIMIT 3");
$topJogadores = $stmt->fetchAll();

jsonResponse([
    'success' => true,
    'estatisticas' => [
        'total_jogadores' => $totalJogadores,
        'jogadores_ativos' => $jogadoresAtivos,
        'jogadores_inativos' => $jogadoresInativos,
        'total_partidas' => $totalPartidas,
        'media_kd' => $mediaKD,
        'media_adr' => $mediaADR
    ],
    'top_jogadores' => $topJogadores
]);
