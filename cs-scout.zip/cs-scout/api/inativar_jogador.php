<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user_id']) || $_SESSION['user_nivel'] !== 'admin') {
    jsonResponse(['success' => false, 'message' => 'Acesso negado.']);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['success' => false, 'message' => 'Método não permitido.']);
}

$id = isset($_POST['id']) ? intval($_POST['id']) : 0;
if ($id <= 0) {
    jsonResponse(['success' => false, 'message' => 'ID inválido.']);
}

$stmt = $pdo->prepare("UPDATE jogadores SET status = 'inativo' WHERE id = :id");
try {
    $stmt->execute([':id' => $id]);
    jsonResponse(['success' => true, 'message' => 'Jogador inativado com sucesso!']);
} catch (PDOException $e) {
    jsonResponse(['success' => false, 'message' => 'Erro ao inativar jogador.']);
}
