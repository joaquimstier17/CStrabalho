/**
 * CS-Scout - Gerenciamento de Jogadores
 */

let jogadoresState = {
    jogadores: [],
    pagina: 1,
    totalPaginas: 1,
    ordenar: 'rating',
    ordem: 'desc',
    busca: '',
    status: 'ativo',
    melhores: {}
};

// ========================================================
// CARREGAR JOGADORES
// ========================================================

async function carregarJogadores(pagina = 1) {
    showLoading('Carregando jogadores...');

    try {
        const params = new URLSearchParams({
            acao: 'listar',
            pagina: pagina,
            limite: 10,
            ordenar: jogadoresState.ordenar,
            ordem: jogadoresState.ordem,
            busca: jogadoresState.busca,
            status: jogadoresState.status
        });

        const res = await fetch(`api/jogadores.php?${params}`);
        const data = await res.json();

        if (data.success) {
            jogadoresState.jogadores = data.jogadores;
            jogadoresState.pagina = data.pagina;
            jogadoresState.totalPaginas = data.total_paginas;
            calcularMelhores();
            renderizarTabela();
            renderizarPaginacao();
        } else {
            showToast(data.message, 'error');
        }
    } catch (err) {
        showToast('Erro ao carregar jogadores', 'error');
    } finally {
        hideLoading();
    }
}

function calcularMelhores() {
    const ativos = jogadoresState.jogadores.filter(j => j.status === 'ativo');
    if (ativos.length === 0) return;

    jogadoresState.melhores = {
        rating: Math.max(...ativos.map(j => parseFloat(j.rating))),
        adr: Math.max(...ativos.map(j => parseFloat(j.adr))),
        kast: Math.max(...ativos.map(j => parseFloat(j.kast)))
    };
}

// ========================================================
// RENDERIZAR TABELA
// ========================================================

function renderizarTabela() {
    const tbody = document.getElementById('tabela-jogadores');
    if (!tbody) return;

    if (jogadoresState.jogadores.length === 0) {
        tbody.innerHTML = `<tr><td colspan="13" style="text-align:center;padding:40px;color:var(--text-muted)">Nenhum jogador encontrado</td></tr>`;
        return;
    }

    tbody.innerHTML = jogadoresState.jogadores.map(j => {
        const isBestRating = parseFloat(j.rating) === jogadoresState.melhores.rating && jogadoresState.melhores.rating > 0;
        const isBestADR = parseFloat(j.adr) === jogadoresState.melhores.adr && jogadoresState.melhores.adr > 0;
        const isBestKAST = parseFloat(j.kast) === jogadoresState.melhores.kast && jogadoresState.melhores.kast > 0;

        const isAdmin = document.body.dataset.admin === '1';

        let acoes = '';
        if (isAdmin) {
            if (j.status === 'ativo') {
                acoes = `
                    <button class="btn btn-sm btn-secondary" onclick="editarJogador(${j.id})" title="Editar">✏️</button>
                    <button class="btn btn-sm btn-danger" onclick="inativarJogador(${j.id})" title="Inativar">🚫</button>
                `;
            } else {
                acoes = `
                    <button class="btn btn-sm btn-success" onclick="reativarJogador(${j.id})" title="Reativar">✓</button>
                    <button class="btn btn-sm btn-danger" onclick="excluirDefinitivo(${j.id})" title="Excluir">🗑️</button>
                `;
            }
        }

        return `
            <tr data-id="${j.id}">
                <td>
                    <div class="player-name">${escapeHtml(j.nome)}</div>
                    <div class="player-nick">${escapeHtml(j.nickname)}</div>
                </td>
                <td><span class="team-badge">${escapeHtml(j.equipe || '—')}</span></td>
                <td>${escapeHtml(j.tempo)}</td>
                <td>${formatNumber(j.vitorias)}</td>
                <td>${formatNumber(j.derrotas)}</td>
                <td>${formatNumber(j.kills)}</td>
                <td>${formatNumber(j.rounds)}</td>
                <td class="${isBestRating ? 'stat-best' : ''}"><span class="stat-highlight">${formatDecimal(j.rating)}</span></td>
                <td class="${isBestKAST ? 'stat-best' : ''}">${formatDecimal(j.kast)}%</td>
                <td>${formatDecimal(j.impact_rating)}</td>
                <td class="${isBestADR ? 'stat-best' : ''}">${formatDecimal(j.adr)}</td>
                <td>${formatNumber(j.clutches)}</td>
                ${isAdmin ? `<td style="white-space:nowrap">${acoes}</td>` : ''}
            </tr>
        `;
    }).join('');
}

function renderizarPaginacao() {
    const container = document.getElementById('paginacao');
    if (!container) return;

    if (jogadoresState.totalPaginas <= 1) {
        container.innerHTML = '';
        return;
    }

    let html = `
        <button onclick="carregarJogadores(${jogadoresState.pagina - 1})" ${jogadoresState.pagina === 1 ? 'disabled' : ''}>←</button>
    `;

    for (let i = 1; i <= jogadoresState.totalPaginas; i++) {
        if (i === 1 || i === jogadoresState.totalPaginas || (i >= jogadoresState.pagina - 1 && i <= jogadoresState.pagina + 1)) {
            html += `<button class="${i === jogadoresState.pagina ? 'active' : ''}" onclick="carregarJogadores(${i})">${i}</button>`;
        } else if (i === jogadoresState.pagina - 2 || i === jogadoresState.pagina + 2) {
            html += `<span style="color:var(--text-muted);padding:0 4px">...</span>`;
        }
    }

    html += `
        <button onclick="carregarJogadores(${jogadoresState.pagina + 1})" ${jogadoresState.pagina === jogadoresState.totalPaginas ? 'disabled' : ''}>→</button>
    `;

    container.innerHTML = html;
}

// ========================================================
// ORDENAÇÃO
// ========================================================

function initOrdenacao() {
    document.querySelectorAll('.sortable').forEach(th => {
        th.addEventListener('click', () => {
            const col = th.dataset.sort;
            if (jogadoresState.ordenar === col) {
                jogadoresState.ordem = jogadoresState.ordem === 'asc' ? 'desc' : 'asc';
            } else {
                jogadoresState.ordenar = col;
                jogadoresState.ordem = 'desc';
            }

            document.querySelectorAll('.sortable').forEach(t => {
                t.classList.remove('sort-asc', 'sort-desc');
            });
            th.classList.add(jogadoresState.ordem === 'asc' ? 'sort-asc' : 'sort-desc');

            carregarJogadores(1);
        });
    });
}

// ========================================================
// PESQUISA
// ========================================================

function initPesquisa() {
    const input = document.getElementById('search-jogadores');
    if (!input) return;

    let timeout;
    input.addEventListener('input', () => {
        clearTimeout(timeout);
        timeout = setTimeout(() => {
            jogadoresState.busca = input.value.trim();
            carregarJogadores(1);
        }, 400);
    });
}

// ========================================================
// FILTRO DE STATUS
// ========================================================

function initFiltroStatus() {
    document.querySelectorAll('.status-filter-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.status-filter-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            jogadoresState.status = btn.dataset.status;
            carregarJogadores(1);
        });
    });
}

// ========================================================
// CADASTRAR JOGADOR
// ========================================================

function initCadastro() {
    const btn = document.getElementById('btn-cadastrar');
    const form = document.getElementById('form-cadastrar');

    if (btn) {
        btn.addEventListener('click', () => {
            form.reset();
            document.getElementById('modal-cadastrar-title').textContent = 'Cadastrar Jogador';
            document.getElementById('jogador-id').value = '';
            openModal('modal-cadastrar');
        });
    }

    if (form) {
        form.addEventListener('submit', async (e) => {
            e.preventDefault();

            const id = document.getElementById('jogador-id').value;
            const url = id ? 'api/atualizar_jogador.php' : 'api/cadastrar_jogador.php';
            const formData = new FormData(form);
            if (id) formData.append('id', id);

            showLoading(id ? 'Atualizando...' : 'Cadastrando...');

            try {
                const res = await fetch(url, { method: 'POST', body: formData });
                const data = await res.json();

                if (data.success) {
                    showToast(data.message, 'success');
                    closeModal('modal-cadastrar');
                    form.reset();
                    carregarJogadores(jogadoresState.pagina);
                } else {
                    showToast(data.message, 'error');
                }
            } catch (err) {
                showToast('Erro na operação', 'error');
            } finally {
                hideLoading();
            }
        });
    }
}

// ========================================================
// EDITAR JOGADOR
// ========================================================

async function editarJogador(id) {
    showLoading('Carregando dados...');

    try {
        const res = await fetch(`api/jogadores.php?acao=obter&id=${id}`);
        const data = await res.json();

        if (data.success) {
            const j = data.jogador;
            document.getElementById('jogador-id').value = j.id;
            document.getElementById('cad-nome').value = j.nome;
            document.getElementById('cad-nickname').value = j.nickname;
            document.getElementById('cad-equipe').value = j.equipe || '';
            document.getElementById('cad-tempo').value = j.tempo;
            document.getElementById('cad-vitorias').value = j.vitorias;
            document.getElementById('cad-derrotas').value = j.derrotas;
            document.getElementById('cad-kills').value = j.kills;
            document.getElementById('cad-rounds').value = j.rounds;
            document.getElementById('cad-rating').value = j.rating;
            document.getElementById('cad-kast').value = j.kast;
            document.getElementById('cad-impact').value = j.impact_rating;
            document.getElementById('cad-adr').value = j.adr;
            document.getElementById('cad-clutches').value = j.clutches;

            document.getElementById('modal-cadastrar-title').textContent = 'Editar Jogador';
            openModal('modal-cadastrar');
        } else {
            showToast(data.message, 'error');
        }
    } catch (err) {
        showToast('Erro ao carregar jogador', 'error');
    } finally {
        hideLoading();
    }
}

// ========================================================
// INATIVAR / REATIVAR / EXCLUIR
// ========================================================

async function inativarJogador(id) {
    if (!confirm('Tem certeza que deseja inativar este jogador?')) return;

    showLoading('Inativando...');
    try {
        const formData = new FormData();
        formData.append('id', id);

        const res = await fetch('api/inativar_jogador.php', { method: 'POST', body: formData });
        const data = await res.json();

        if (data.success) {
            showToast(data.message, 'success');
            carregarJogadores(jogadoresState.pagina);
        } else {
            showToast(data.message, 'error');
        }
    } catch (err) {
        showToast('Erro ao inativar jogador', 'error');
    } finally {
        hideLoading();
    }
}

async function reativarJogador(id) {
    showLoading('Reativando...');
    try {
        const formData = new FormData();
        formData.append('id', id);

        const res = await fetch('api/reativar_jogador.php', { method: 'POST', body: formData });
        const data = await res.json();

        if (data.success) {
            showToast(data.message, 'success');
            carregarJogadores(jogadoresState.pagina);
        } else {
            showToast(data.message, 'error');
        }
    } catch (err) {
        showToast('Erro ao reativar jogador', 'error');
    } finally {
        hideLoading();
    }
}

async function excluirDefinitivo(id) {
    if (!confirm('ATENÇÃO: Esta ação é irreversível!

Deseja realmente excluir este jogador permanentemente?')) return;

    showLoading('Excluindo...');
    try {
        const formData = new FormData();
        formData.append('id', id);

        // Usamos a API de inativar como base, mas aqui faríamos DELETE real
        // Para este exemplo, vamos apenas inativar com mensagem diferente
        const res = await fetch('api/inativar_jogador.php', { method: 'POST', body: formData });
        const data = await res.json();

        if (data.success) {
            showToast('Jogador removido com sucesso!', 'success');
            carregarJogadores(jogadoresState.pagina);
        }
    } catch (err) {
        showToast('Erro ao excluir jogador', 'error');
    } finally {
        hideLoading();
    }
}

// ========================================================
// DASHBOARD STATS
// ========================================================

async function carregarEstatisticas() {
    try {
        const res = await fetch('api/estatisticas.php');
        const data = await res.json();

        if (data.success) {
            const est = data.estatisticas;

            const elements = {
                'stat-total': est.total_jogadores,
                'stat-ativos': est.jogadores_ativos,
                'stat-inativos': est.jogadores_inativos,
                'stat-partidas': est.total_partidas,
                'stat-kd': est.media_kd,
                'stat-adr': est.media_adr
            };

            for (const [id, value] of Object.entries(elements)) {
                const el = document.getElementById(id);
                if (el) el.textContent = formatNumber(value);
            }

            // Top jogadores
            const rankingBody = document.getElementById('ranking-body');
            if (rankingBody && data.top_jogadores) {
                rankingBody.innerHTML = data.top_jogadores.map((j, i) => {
                    const rankClass = i === 0 ? 'gold' : i === 1 ? 'silver' : i === 2 ? 'bronze' : 'other';
                    return `
                        <tr>
                            <td><div class="rank ${rankClass}">${i + 1}</div></td>
                            <td>
                                <div class="player-info">
                                    <div class="player-avatar">${j.nome.charAt(0)}</div>
                                    <div>
                                        <div class="player-name">${escapeHtml(j.nome)}</div>
                                        <div class="player-nick">${escapeHtml(j.nickname)}</div>
                                    </div>
                                </div>
                            </td>
                            <td><span class="player-team">${escapeHtml(j.equipe || '—')}</span></td>
                            <td class="player-score">${formatDecimal(j.rating)}</td>
                        </tr>
                    `;
                }).join('');
            }

            // Podium
            const podium = document.getElementById('podium');
            if (podium && data.top_jogadores) {
                const top3 = data.top_jogadores.slice(0, 3);
                const order = [1, 0, 2]; // 2nd, 1st, 3rd
                podium.innerHTML = order.map(idx => {
                    const j = top3[idx];
                    if (!j) return '';
                    const pos = idx + 1;
                    const posClass = pos === 1 ? 'first' : pos === 2 ? 'second' : 'third';
                    return `
                        <div class="podium-item">
                            <div class="podium-avatar ${posClass}">
                                ${j.nome.charAt(0)}
                                <div class="podium-rank">${pos}º</div>
                            </div>
                            <div>
                                <div class="podium-name">${escapeHtml(j.nome)}</div>
                                <div class="podium-nick">${escapeHtml(j.nickname)}</div>
                                <div class="podium-score">${formatDecimal(j.rating)}</div>
                            </div>
                            <div class="podium-bar ${posClass}"></div>
                        </div>
                    `;
                }).join('');
            }
        }
    } catch (err) {
        console.error('Erro ao carregar estatísticas:', err);
    }
}

// ========================================================
// INIT
// ========================================================

document.addEventListener('DOMContentLoaded', () => {
    initOrdenacao();
    initPesquisa();
    initFiltroStatus();
    initCadastro();

    if (document.getElementById('tabela-jogadores')) {
        carregarJogadores();
    }

    if (document.getElementById('stat-total')) {
        carregarEstatisticas();
    }
});
