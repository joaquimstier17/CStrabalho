/**
 * CS-Scout - Login
 */

document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('login-form');
    const errorDiv = document.getElementById('login-error');
    const btn = document.getElementById('login-btn');

    if (!form) return;

    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        const usuario = document.getElementById('usuario').value.trim();
        const senha = document.getElementById('senha').value;

        if (!usuario || !senha) {
            showError('Preencha todos os campos.');
            return;
        }

        btn.disabled = true;
        btn.textContent = 'Entrando...';
        errorDiv.classList.remove('show');

        try {
            const formData = new FormData();
            formData.append('usuario', usuario);
            formData.append('senha', senha);

            const res = await fetch('api/login.php', {
                method: 'POST',
                body: formData
            });

            const data = await res.json();

            if (data.success) {
                window.location.href = data.redirect;
            } else {
                showError(data.message || 'Erro ao fazer login.');
                btn.disabled = false;
                btn.textContent = 'Entrar';
            }
        } catch (err) {
            showError('Erro de conexão. Tente novamente.');
            btn.disabled = false;
            btn.textContent = 'Entrar';
        }
    });

    function showError(msg) {
        errorDiv.textContent = msg;
        errorDiv.classList.add('show');
    }
});
